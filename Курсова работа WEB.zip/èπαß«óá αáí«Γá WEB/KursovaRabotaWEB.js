function sayColor(colorName) {
    const utterance = new SpeechSynthesisUtterance(colorName);
    utterance.lang = 'bg-BG'; // Задаваме език на български
    speechSynthesis.speak(utterance);}